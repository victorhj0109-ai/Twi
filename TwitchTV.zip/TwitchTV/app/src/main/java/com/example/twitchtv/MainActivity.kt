package com.example.twitchtv

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.Text
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

object Store {
    lateinit var ctx: Context
    private val sp get() = ctx.getSharedPreferences("auth", Context.MODE_PRIVATE)
    var token: String?
        get() = sp.getString("token", null)
        set(v) { sp.edit().putString("token", v).apply() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.ctx = applicationContext
        setContent { App() }
    }
}

@Composable
fun App() {
    var watching by remember { mutableStateOf<Stream?>(null) }
    val s = watching
    if (s == null) HomeScreen { watching = it } else PlayerScreen(s.login, s.name) { watching = null }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun HomeScreen(onOpen: (Stream) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var streams by remember { mutableStateOf<List<Stream>>(emptyList()) }
    var token by remember { mutableStateOf(Store.token) }
    var err by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    var go by remember { mutableIntStateOf(0) }
    LaunchedEffect(tab, token, go) {
        loading = true; err = ""
        try {
            streams = when (tab) {
                0 -> Twitch.topStreams()
                1 -> token?.let { Twitch.followed(Config.CLIENT_ID, it) } ?: emptyList()
                else -> if (query.isBlank()) emptyList() else Twitch.search(query)
            }
        } catch (e: Exception) { streams = emptyList(); err = e.message ?: e.toString() }
        loading = false
    }
    Column(Modifier.fillMaxSize().background(Bg).padding(32.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Twitch TV", color = Purple, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            PButton("Ao vivo", tab == 0) { tab = 0 }
            PButton("Seguindo", tab == 1) { tab = 1 }
            PButton("🔍 Buscar", tab == 2) { tab = 2 }
        }
        Spacer(Modifier.height(24.dp))
        if (tab == 2) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 20.sp),
                    cursorBrush = SolidColor(Purple),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { go++ }),
                    modifier = Modifier.width(500.dp).background(Panel, RoundedCornerShape(12.dp)).padding(16.dp),
                    decorationBox = { inner -> if (query.isEmpty()) Text("Nome do canal…", color = Color.Gray); inner() }
                )
                PButton("Buscar") { go++ }
            }
            Spacer(Modifier.height(16.dp))
        }
        when {
            tab == 1 && token == null -> LoginPanel { Store.token = it; token = it }
            loading -> Text("Carregando…", color = Color.Gray)
            err.isNotEmpty() -> Text("Erro: $err", color = Color.Red)
            streams.isEmpty() -> Text(if (tab == 2) "Digite um canal e busque." else "Nada encontrado.", color = Color.Gray)
            else -> LazyVerticalGrid(GridCells.Adaptive(290.dp), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                items(streams) { s -> Card(s.thumb, s.title.ifEmpty { s.name }, s.name, if (s.viewers > 0) "${s.game} · ${s.viewers} espectadores" else s.game) { onOpen(s) } }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun LoginPanel(onToken: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf<DeviceCode?>(null) }
    var err by remember { mutableStateOf("") }
    if (Config.CLIENT_ID.isBlank()) {
        Text("Para entrar, coloque seu Client ID em Config.kt. Sem login você já pode assistir na aba Ao vivo.", color = androidx.compose.ui.graphics.Color.White)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        val c = code
        if (c == null) PButton("Entrar com a Twitch") {
            scope.launch {
                runCatching {
                    val d = Twitch.deviceStart(Config.CLIENT_ID); code = d
                    repeat(120) {
                        delay(d.interval * 1000L)
                        Twitch.devicePoll(Config.CLIENT_ID, d.deviceCode)?.let { t -> onToken(t); return@runCatching }
                    }
                }.onFailure { err = "Falha no login." }
            }
        } else {
            Text("No celular, abra ${c.uri} e digite o código:", color = androidx.compose.ui.graphics.Color.White)
            Text(c.userCode, color = Purple, fontSize = 40.sp, fontWeight = FontWeight.Bold)
        }
        if (err.isNotEmpty()) Text(err, color = androidx.compose.ui.graphics.Color.Red)
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun PlayerScreen(login: String, name: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var seekEnd by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<List<Media>>(emptyList()) }
    var msg by remember { mutableStateOf("") }

    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && seekEnd) {
                    seekEnd = false
                    player.seekTo((player.duration - 20_000).coerceAtLeast(0))
                }
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    fun play(toEnd: Boolean = false, load: suspend () -> String) {
        scope.launch {
            msg = "Carregando…"
            runCatching { load() }.onSuccess {
                seekEnd = toEnd
                player.setMediaItem(MediaItem.fromUri(it)); player.prepare(); player.playWhenReady = true; msg = ""
            }.onFailure { msg = "Não foi possível carregar (canal offline ou sem VOD ativado)." }
        }
    }
    LaunchedEffect(Unit) { play { Twitch.liveUrl(login) } }
    BackHandler(onBack = onBack)

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(name, color = Purple, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            PButton("Ao vivo") { play { Twitch.liveUrl(login) } }
            PButton("Voltar no tempo") {
                play(true) { Twitch.vodUrl(Twitch.latestVodId(login) ?: error("sem vod")) }
            }
            PButton("Clips") { scope.launch { panel = runCatching { Twitch.clips(login) }.getOrDefault(emptyList()) } }
            PButton("VODs") { scope.launch { panel = runCatching { Twitch.vods(login) }.getOrDefault(emptyList()) } }
            if (msg.isNotEmpty()) Text(msg, color = androidx.compose.ui.graphics.Color.Gray, fontSize = 14.sp)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxSize())
        }
        if (panel.isNotEmpty()) LazyRow(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(panel) { m ->
                Card(m.thumb, m.title, if (m.isClip) "Clip" else "VOD", "${m.views} views") { play { Twitch.mediaUrl(m) } }
            }
        }
    }
}
