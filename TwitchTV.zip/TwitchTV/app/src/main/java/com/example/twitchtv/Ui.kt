package com.example.twitchtv

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.*
import coil.compose.AsyncImage

val Bg = Color(0xFF0A0A0F)
val Panel = Color(0xFF17131F)
val Purple = Color(0xFF9146FF)

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun PButton(text: String, selected: Boolean = false, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.colors(
            containerColor = if (selected) Purple else Panel, contentColor = Color.White,
            focusedContainerColor = Purple, focusedContentColor = Color.White
        )
    ) { Text(text) }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun Card(thumb: String, title: String, line1: String, line2: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(12.dp)),
        colors = ClickableSurfaceDefaults.colors(containerColor = Panel, focusedContainerColor = Color(0xFF2A1F40)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.06f),
        modifier = Modifier.width(280.dp)
    ) {
        Column {
            AsyncImage(thumb, null, Modifier.fillMaxWidth().aspectRatio(16 / 9f).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
            Column(Modifier.padding(10.dp)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(line1, color = Purple, fontSize = 12.sp, maxLines = 1)
                Text(line2, color = Color.Gray, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}
