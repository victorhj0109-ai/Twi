package com.example.twitchtv

object Config {
    // Cole aqui seu Client ID (https://dev.twitch.tv/console) para habilitar o login.
    // Em branco: o app funciona normalmente, só sem a aba "Seguindo".
    const val CLIENT_ID = ""
}
