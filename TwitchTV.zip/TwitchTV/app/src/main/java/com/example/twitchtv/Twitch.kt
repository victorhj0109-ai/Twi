package com.example.twitchtv

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder

data class Stream(val login: String, val name: String, val title: String, val game: String, val viewers: Int, val thumb: String)
data class Media(val id: String, val isClip: Boolean, val title: String, val thumb: String, val views: Int)
data class DeviceCode(val deviceCode: String, val userCode: String, val uri: String, val interval: Int)

object Twitch {
    // Client ID público do site da Twitch (usado por players alternativos). Permite usar o app sem login.
    private const val WEB = "kimne78kx3ncx6brgo4mv6wki5h1ko"
    private val http = OkHttpClient()
    private val JSON_T = "application/json".toMediaType()
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun gql(q: String): JSONObject {
        val body = JSONObject().put("query", q).toString().toRequestBody(JSON_T)
        val req = Request.Builder().url("https://gql.twitch.tv/gql").header("Client-ID", WEB).post(body).build()
        http.newCall(req).execute().use {
            val txt = it.body!!.string()
            val j = JSONObject(txt)
            if (!j.has("data") || j.isNull("data"))
                throw Exception(j.optJSONArray("errors")?.optJSONObject(0)?.optString("message") ?: "HTTP ${it.code}: ${txt.take(120)}")
            return j
        }
    }

    private const val PARAMS = """params: { platform: "web", playerBackend: "mediaplayer", playerType: "site" }"""

    suspend fun topStreams(): List<Stream> = withContext(Dispatchers.IO) {
        val e = gql("""{ streams(first: 40) { edges { node { title viewersCount
            previewImageURL(width: 640, height: 360) broadcaster { login displayName } game { name } } } } }""")
            .getJSONObject("data").getJSONObject("streams").getJSONArray("edges")
        (0 until e.length()).map {
            val n = e.getJSONObject(it).getJSONObject("node"); val b = n.getJSONObject("broadcaster")
            Stream(b.getString("login"), b.getString("displayName"), n.optString("title"),
                n.optJSONObject("game")?.optString("name") ?: "", n.optInt("viewersCount"), n.optString("previewImageURL"))
        }
    }

    private fun userToStream(n: JSONObject): Stream {
        val s = n.optJSONObject("stream")
        return Stream(n.getString("login"), n.optString("displayName", n.getString("login")),
            s?.optString("title") ?: "", s?.optJSONObject("game")?.optString("name") ?: "Offline",
            s?.optInt("viewersCount") ?: 0, n.optString("profileImageURL"))
    }

    suspend fun search(q: String): List<Stream> = withContext(Dispatchers.IO) {
        val c = q.filter { it.isLetterOrDigit() || it == '_' || it == ' ' }.trim()
        val f = "login displayName profileImageURL(width: 300) stream { title viewersCount game { name } }"
        try {
            val e = gql("""{ searchUsers(userQuery: "$c", first: 24) { edges { node { $f } } } }""")
                .getJSONObject("data").getJSONObject("searchUsers").getJSONArray("edges")
            (0 until e.length()).map { userToStream(e.getJSONObject(it).getJSONObject("node")) }
        } catch (ex: Exception) {
            val u = gql("""{ user(login: "${c.replace(" ", "").lowercase()}") { $f } }""").getJSONObject("data").optJSONObject("user")
            if (u == null) emptyList() else listOf(userToStream(u))
        }
    }

    suspend fun followed(clientId: String, token: String): List<Stream> = withContext(Dispatchers.IO) {
        fun get(url: String): JSONObject {
            val r = Request.Builder().url(url).header("Client-Id", clientId).header("Authorization", "Bearer $token").build()
            http.newCall(r).execute().use { return JSONObject(it.body!!.string()) }
        }
        val uid = get("https://api.twitch.tv/helix/users").getJSONArray("data").getJSONObject(0).getString("id")
        val d = get("https://api.twitch.tv/helix/streams/followed?user_id=$uid&first=100").getJSONArray("data")
        (0 until d.length()).map {
            val s = d.getJSONObject(it)
            Stream(s.getString("user_login"), s.getString("user_name"), s.optString("title"), s.optString("game_name"),
                s.optInt("viewer_count"), s.optString("thumbnail_url").replace("{width}", "640").replace("{height}", "360"))
        }
    }

    suspend fun liveUrl(login: String): String = withContext(Dispatchers.IO) {
        val t = gql("""{ streamPlaybackAccessToken(channelName: "$login", $PARAMS) { value signature } }""")
            .getJSONObject("data").getJSONObject("streamPlaybackAccessToken")
        "https://usher.ttvnw.net/api/channel/hls/$login.m3u8?sig=${t.getString("signature")}&token=${enc(t.getString("value"))}" +
            "&allow_source=true&allow_audio_only=true&player=twitchweb&p=${(0..999999).random()}"
    }

    suspend fun latestVodId(login: String): String? = withContext(Dispatchers.IO) {
        val e = gql("""{ user(login: "$login") { videos(first: 1, type: ARCHIVE, sort: TIME) { edges { node { id } } } } }""")
            .getJSONObject("data").optJSONObject("user")?.getJSONObject("videos")?.getJSONArray("edges")
        if (e == null || e.length() == 0) null else e.getJSONObject(0).getJSONObject("node").getString("id")
    }

    suspend fun vods(login: String): List<Media> = withContext(Dispatchers.IO) {
        val e = gql("""{ user(login: "$login") { videos(first: 20, type: ARCHIVE, sort: TIME) { edges { node {
            id title viewCount previewThumbnailURL(width: 320, height: 180) } } } } }""")
            .getJSONObject("data").optJSONObject("user")?.getJSONObject("videos")?.getJSONArray("edges")
        if (e == null) emptyList() else (0 until e.length()).map {
            val n = e.getJSONObject(it).getJSONObject("node")
            Media(n.getString("id"), false, n.optString("title"), n.optString("previewThumbnailURL"), n.optInt("viewCount"))
        }
    }

    suspend fun clips(login: String): List<Media> = withContext(Dispatchers.IO) {
        val e = gql("""{ user(login: "$login") { clips(first: 20, criteria: { period: LAST_MONTH, sort: VIEWS_DESC }) { edges { node {
            slug title viewCount thumbnailURL } } } } }""")
            .getJSONObject("data").optJSONObject("user")?.getJSONObject("clips")?.getJSONArray("edges")
        if (e == null) emptyList() else (0 until e.length()).map {
            val n = e.getJSONObject(it).getJSONObject("node")
            Media(n.getString("slug"), true, n.optString("title"), n.optString("thumbnailURL"), n.optInt("viewCount"))
        }
    }

    suspend fun vodUrl(id: String): String = withContext(Dispatchers.IO) {
        val t = gql("""{ videoPlaybackAccessToken(id: "$id", $PARAMS) { value signature } }""")
            .getJSONObject("data").getJSONObject("videoPlaybackAccessToken")
        "https://usher.ttvnw.net/vod/$id.m3u8?nauth=${enc(t.getString("value"))}&nauthsig=${t.getString("signature")}&allow_source=true&player=twitchweb"
    }

    suspend fun clipUrl(slug: String): String = withContext(Dispatchers.IO) {
        val c = gql("""{ clip(slug: "$slug") { playbackAccessToken(params: { platform: "web", playerType: "site" }) { signature value }
            videoQualities { sourceURL quality } } }""").getJSONObject("data").getJSONObject("clip")
        val t = c.getJSONObject("playbackAccessToken")
        c.getJSONArray("videoQualities").getJSONObject(0).getString("sourceURL") +
            "?sig=${t.getString("signature")}&token=${enc(t.getString("value"))}"
    }

    suspend fun mediaUrl(m: Media) = if (m.isClip) clipUrl(m.id) else vodUrl(m.id)

    // ---- Login (device code flow, ideal para TV) ----
    suspend fun deviceStart(clientId: String): DeviceCode = withContext(Dispatchers.IO) {
        val body = FormBody.Builder().add("client_id", clientId).add("scopes", "user:read:follows").build()
        http.newCall(Request.Builder().url("https://id.twitch.tv/oauth2/device").post(body).build()).execute().use {
            val j = JSONObject(it.body!!.string())
            DeviceCode(j.getString("device_code"), j.getString("user_code"), j.getString("verification_uri"), j.optInt("interval", 5))
        }
    }

    suspend fun devicePoll(clientId: String, device: String): String? = withContext(Dispatchers.IO) {
        val body = FormBody.Builder().add("client_id", clientId).add("scopes", "user:read:follows")
            .add("device_code", device).add("grant_type", "urn:ietf:params:oauth:grant-type:device_code").build()
        http.newCall(Request.Builder().url("https://id.twitch.tv/oauth2/token").post(body).build()).execute().use {
            if (it.isSuccessful) JSONObject(it.body!!.string()).getString("access_token") else null
        }
    }
}
